package YGOscanner.core;

public interface Observer {
     void update();
}
