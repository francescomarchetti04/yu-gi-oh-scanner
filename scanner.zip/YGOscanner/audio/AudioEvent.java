package YGOscanner.audio;

public enum AudioEvent {
    CARD_IN,
    CARD_STABLE,
    CARD_OUT,
    ERROR
}
