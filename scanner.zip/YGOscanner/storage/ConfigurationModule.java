package YGOscanner.storage;
public class ConfigurationModule {

    public void loadConfig() {
        // carica parametri da SD
    }

    public void saveConfig() {
        // salva parametri
    }

    public void resetDefaults() {
        // fallback
    }
}
