package YGOscanner.camera;

public class Bitmap {
    // Dummy per VS Code
}

