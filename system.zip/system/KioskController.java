package YGOscanner.system;
public class KioskController {

    public void enableKioskMode() {
        // blocco UI e tasti
    }

    public void disableSystemUI() {
        // sblocca UI (debug)
    }

    public void lockScreen() {
        // schermata fissa
    }
}
